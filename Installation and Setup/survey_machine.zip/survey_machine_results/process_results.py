import csv, json

csvfile = 'pavillions-report.csv'
image_code_index = 4

with open('web_index.json', 'r') as j:
	existing = json.load(j)
	j.close()

    
head_reader= csv.reader(open(csvfile, 'r'))
header=head_reader.next()

reader = csv.DictReader(open(csvfile, 'r'), header)
presults = [row for row in reader]
results =[]

for r in presults[1:]:
    imgcode = r[header[image_code_index]].strip()
    imgstr = imgcode[-4:]
    #print imgstr
    try:
        imgnum = int(imgstr)
        if ((0 <= imgnum < 1024)): 
            r['filename'] = imgstr + '.jpg'
            #print r['filename']
            results.append(r)
    except: 
        print "turk entered bad image code: ", imgcode
        
print 'Useable results = ', len(results), '/', len(presults)

questions = header[4:]
meta = {'questions' : questions}

for image in existing:
    image['answers'] = []
    image['turkers'] = []
    #print image['filename']
    for result in results:
        if (result['filename'] == image['filename']): 
            image['answers'].append([result[q] for q in questions])
        
    if (len(image['answers'])> 0):
        try : 
            
            for answer in image['answers']:
                filename = 'output/' + answer[0] + '.json'
                #print filename
                with open (filename) as l:
                    data = json.load(l)
                    if (data['metaData']['mTurkWorkerID'] == ""):
                        image['turkers'].append('unknown turker')
                    else:
                        image['turkers'].append(data['metaData']['mTurkWorkerID'])
                    l.close()
        except : pass

new_index = {'meta':meta, 'data':existing}

with open('index_w_answers.json', 'w') as k:
    k.write(json.dumps(new_index))
    k.close()