<?php



$update = True;

// Get the data from post and filename from query 
$jsonData=$GLOBALS['HTTP_RAW_POST_DATA']; // but the post data into jsonData. Expecting a json string, formatted by JavaScript.





// expecting url keys: $filename 
parse_str($_SERVER['QUERY_STRING']); // parse the url keys and embed them in the local namespace. 
if (!isset($filename)){ $filename="_out".$count; } // default value for filename if none specified.

// Save file
$fp = fopen( $filename, 'wb' );
fwrite( $fp, $jsonData);
fclose( $fp );


?>