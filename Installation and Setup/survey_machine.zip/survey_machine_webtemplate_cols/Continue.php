<?php
	session_start();
	$_SESSION["page_num"]  += 1;

	
	if ($_SESSION["page_num"] < $_SESSION["max"]){
		$_SESSION["done"]= false;
	}else{
		$_SESSION["done"]= true;
	}
	#Some php
	$configFilename = "image_key.json";
	//$current_turker = $_SESSION["turker"];
	$fp = fopen($configFilename, "r"); 
	$stringJSON = fread($fp, filesize($configFilename)); 
	fclose($fp); 
	$configObject = json_decode($stringJSON, true);
	unset($stringJSON);
	unset($fp);
	usort($configObject, function($a, $b) {
		return $a["visits"] - $b["visits"];
	});
	
	if($_SESSION["done"] == false){
		$configObject[0]["visits"] += 1;
		$imgName = $configObject[0]["filename"];
		$jsonData = json_encode($configObject);
		
		$fp = fopen( $configFilename, 'wb' );
		fwrite( $fp, $jsonData);	
		fclose( $fp );
	}else{
		$typeform_apikey = "8ee8cfade31b48c6c50041b7bebea5a0a6fa0666"; //enter your typeform API Key here
		$survey_id = "B3UE5G";
		$json_results_call = "https://api.typeform.com/v0/form/".$survey_id."?key=".$typeform_apikey."&completed=true";
		$typeform_object = file_get_contents($json_results_call);
		$typeform_objectP = json_decode($typeform_object, true);
		//find question id
		$question_ID = $typeform_objectP['questions'][0]['id'];
		//create an array of img codes from valid responses
		$responses_array = $typeform_objectP['responses'];
		//create file directory array
		$answer_filenames = scandir("output");
		//cross check files, generate reports
		
		$turker_responses = 0;
		$img_list = array();
		foreach ($answer_filenames as &$response_filename){
			if (strlen($response_filename) > 6){
				$response_filedir = 'output/'.$response_filename;
				$fr = fopen($response_filedir, "r");
				$stringJSON = fread($fr, filesize($response_filedir));
				fclose($fr);
				$respFileObject = json_decode($stringJSON, true);
				unset($stringJSON);
				unset($fr);
				if ($respFileObject['metaData']["mTurkWorkerID"] == $_SESSION["turker"]){ $turker_responses += 1;}
				array_push($img_list, $respFileObject['metaData']['imageName']);
			}	
		}
		//publish report
		$turkerObject = array('responses' => $turker_responses, 'turkerID' => $_SESSION["turker"]);
		$turkjsonbit = json_encode($turkerObject);
		$reportFilename = 'reports/'.$_SESSION["turker"].'.json';
		$ft = fopen( $reportFilename, 'wb' );
		fwrite( $ft, $turkjsonbit);	
		fclose( $ft );
		
		foreach ($configObject as &$count_object){
			$name_to_count = $count_object['filename'];
			// count number of occurrences
			$count = 0;
			foreach ($img_list as &$value){
				if ($value == $name_to_count) {$count +=1;}
			}
			//overwrite
			$count_object['visits'] = $count;
		}
		//update results list:
		
		
		$jsonData = json_encode($configObject);
		$fp = fopen( $configFilename, 'wb' );
		fwrite( $fp, $jsonData);	
		fclose( $fp );
	}
?>

<!-- DOCTYPE: Html5 -->
<html>
<head>
<script type = "text/javascript" src="js/jquery-1.11.1.min.js"></script>
<script type="text/javascript">
	
	var your_survey_url = "https://ksteinfe.typeform.com/to/B3UE5G";  //Enter your survey url
	var confirmation_string = "L3VART"; //Use this key to quickly identify whether someone has completed your survey
	var projectTitle = "teacup survey";
	var img_width = 450;
	

	//var sessionID;  //internally computed
	var mTurkWorkerID = (<?php echo json_encode($_SESSION['turker']); ?> );
	var mTurkAssignmentID = (<?php echo json_encode($_SESSION['assignmentID']); ?> );
	var mTurkHitID = (<?php echo json_encode($_SESSION['hitID']); ?> );
	var imageFilename = "";
	console.log(mTurkWorkerID);
	
	console.log(<?php echo json_encode($configObject[0]); ?> );
	
	function done(){
		//generate completion code
		var completion_code = setCompletionCode();
		var thanks_message = "Thanks for completing this survey, please return to Mechanical Turk and enter the following Code:";
		//generate page text
		document.getElementById('bottom_survey').style.height = "0px";
		document.getElementById('image-wrapper').innerHTML = thanks_message;
		document.getElementById('surveyCodeKey').innerHTML = completion_code;
		
		//var typeform = <?php echo json_encode($typeform_object); ?>;
		//var question_ID = <?php echo json_encode($question_ID); ?>;
		var filenames = <?php echo json_encode($answer_filenames); ?>;
		var turkerobject = <?php echo json_encode($turkerObject); ?>;
		var imglist = <?php echo json_encode($img_list); ?>;
		var respfileobj =<?php echo json_encode($respFileObject); ?>; 
		//console.log(question_ID);
		//console.log(typeform);
		console.log(turkerobject);
		console.log(filenames);
		console.log(imglist);
		console.log(respfileobj);
	}
		function init(){
		var clwidth = document.body.clientWidth;
		clwidth -= img_width + 20;
		clwidthstr = clwidth.toString() + 'px';
		var bottom_survey = document.getElementById('bottom_survey');
		var ext_survey = document.createElement('iframe');
		bottom_survey.style.float = 'right';
		console.log(clwidthstr);
		bottom_survey.style.width = clwidthstr;
		bottom_survey.style.display = 'inline-block'
		ext_survey.id = 'ext_survey';
		ext_survey.src = your_survey_url;
		ext_survey.style.width = '100%';
		ext_survey.style.height = '100%';
		bottom_survey.appendChild(ext_survey);
		leftcolumn = document.getElementById("img_key");
		leftcolumn.style.top = '50%';
		leftcolumn.style.width = (img_width + 20).toString() +'px';
		leftcolumn.style.transform = 'translateY(50%)';
		selectImage();
		window.addEventListener( 'resize', onWindowResize, false );
		
	}
	function onWindowResize(){
		clwidth = document.body.clientWidth;
		clwidth -= img_width + 20;
		clwidthstr = clwidth.toString() + 'px';
		console.log(clwidthstr);
		bottom_survey.style.width = clwidthstr;
		leftcolumn.style.top = '50%';
		leftcolumn.style.transform = 'translateY(50%)';
		
		
	}
	function compare(a, b){
			if (this.visits < this.visits){return -1;}
			if (this.visits > this.visits){return 1;}
			return 0;
		}
	
	function selectImage(){
		imageFilename = <?php echo json_encode($imgName); ?>;
		var imageFileDir ='images/' + imageFilename;
		var imageFileStrings = imageFilename.split(".");
		imageFileNum = imageFileStrings[0];
		setPicID();
		//plcer 
		var img_place = document.getElementById('image-wrapper');
		document.getElementById('top-reference').style.width = img_width.toString() +'px';
		img_place.style.width = img_width.toString() +'px';
		var img_tag = document.createElement('img');
		img_tag.src = imageFileDir;
		img_place.appendChild(img_tag);
	}
	
	function postData() {
		//JSON.stringify(data);// json-a-fy the array
		//JSON.parse(dataJSON); // then latter parse 
		endTime = Date.now();
		//elapsedTime = (endTime - startTime)/1000; // in seconds
		//console.log("Elapsed Time (s): " + elapsedTime);

		endDate = new Date();


		var dataFilename = "output/" + surveyHITCode + ".json";
		dataFilename = dataFilename.replace(/[\r\n]/g, "");
		console.log(dataFilename);
		var postURL = "saveFile.php?filename=" + dataFilename + "&name=" + mTurkWorkerID;
		console.log(postURL);
		
		//'sessionID' : sessionID,
		var metaData = {
			"dataFilename" : dataFilename,
			"date" : endDate,
			'mTurkWorkerID' : mTurkWorkerID,
			'mTurkHitID' : mTurkHitID,
			'mTurkAssignmentID' : mTurkAssignmentID, 			
			'ProjectName' : projectTitle,
			'imageName' : imageFilename,
			'surveyHITCode':surveyHITCode
			};

		

		var dataFile = {"metaData":metaData};
		dataFileJSON = JSON.stringify(dataFile);

		var ajax = new XMLHttpRequest();

		ajax.open("POST", postURL, false);
		ajax.setRequestHeader("Content-Type", "application/upload");
		ajax.send(dataFileJSON); //send data and json object with worker/job info.

	}
	
	function setPicID() {
		var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		surveyHITCode = "";
		for (var i=0; i < 6; i++ ) { surveyHITCode += possible.charAt(Math.floor(Math.random() * possible.length)); }
		surveyHITCode = surveyHITCode + imageFileNum;
		document.getElementById('surveyCodeKey').innerHTML = surveyHITCode;
	}
	function setCompletionCode() {
		var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		sessionID = "";
		for (var i=0; i < 19; i++ ) { sessionID += possible.charAt(Math.floor(Math.random() * possible.length)); }
		return (sessionID += confirmation_string)
	}
	
	
	function getURLParameter( name ){
		name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
		var regexS = "[\\?&]"+name+"=([^&#]*)";
		var regex = new RegExp( regexS );
		var results = regex.exec( window.location.href );
		if( results == null )
			return "";
		else
			return results[1];
		}
	
</script>
<style>
	body{
		margin : 0px
	}


</style>
</head>
<body>
<input type = "hidden" id = "workerID" value = "" />

<div id="survey-wrap" style ="width:100%; height:100%; display:inline-block">
<div id="bottom_survey" style ="height:100%"></div>
<div id="img_key" style="top:50%; transform: translateY(50%)">
	<span align="center">
		<div id="top-reference" style = "padding:10px; display:inline-block"><p id="surveyCodeKey" ></p></div>
		<div id="image-wrapper" style = "padding:10px; display:inline-block;" ></div>
	</span>
</div>
</div>
<script type="text/javascript">
	var isFinished = false;
	var isFinished = <?php echo json_encode($_SESSION["done"]); ?>;
	if (isFinished){
		done();

	}else{
		init();
		postData();
	}
</script>

</body>

</html>
