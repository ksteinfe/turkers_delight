#Setup Script:
#creates a key JSON for tracking the images
import json
import os

img_dir = "images/"
json_objs = []

for img_name in os.listdir(img_dir):
    img_name = str(img_name) 
    print img_name
    json_obj = {}
    json_obj['filename'] = img_name
    json_obj['visits'] = 0
    json_objs.append(json_obj)
	
print "done. writing JSON"
with open("image_key.json", 'w') as j:
    j.write(json.dumps(json_objs))
    j.close()