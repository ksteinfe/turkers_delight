<?php
	$questionNum = 3;
	
	session_start();
	$_SESSION["page_num"]  = 0;
	$_SESSION["done"] = false;
	$_SESSION["max"] = $questionNum;
	#Some php
	$configFilename = "image_key.json";

	$fp = fopen($configFilename, "r"); 
	$stringJSON = fread($fp, filesize($configFilename)); 
	fclose($fp); 
	$configObject = json_decode($stringJSON, true);
	usort($configObject, function($a, $b) {
		return $a["visits"] - $b["visits"];
	});
	
	$configObject[0]["visits"] += 1;
	$imgName = $configObject[0]["filename"];
	$jsonData = json_encode($configObject);
	
	$fp = fopen( $configFilename, 'wb' );
	fwrite( $fp, $jsonData);	
	fclose( $fp );
	
?>

<!-- DOCTYPE: Html5 -->
<html>
<head>
<script type = "text/javascript" src="js/jquery-1.11.1.min.js"></script>
<script type="text/javascript">
	
	var your_survey_url = "https://ksteinfe.typeform.com/to/B3UE5G";  //Enter your survey url
	var confirmation_string = "L3VART"; //Use this key to quickly identify whether someone has completed your survey
	var projectTitle = "teacup survey";
	var img_width = 450;
	

	//var sessionID;  //internally computed
	var mTurkWorkerID = getURLParameter( 'workerId' );
	var mTurkAssignmentID = getURLParameter( 'assignmentId' );
	var mTurkHitID = getURLParameter( 'hitId' );
	//var mTurkAssignmentID = 'assignment5' ;
	//var mTurkHitID =  'hit5' ;	
	var imageFilename = "";
	
	console.log(<?php echo json_encode($configObject[0]); ?> );
	function init(){
		var clwidth = document.body.clientWidth;
		clwidth -= img_width + 20;
		clwidthstr = clwidth.toString() + 'px';
		var bottom_survey = document.getElementById('bottom_survey');
		var ext_survey = document.createElement('iframe');
		bottom_survey.style.float = 'right';
		console.log(clwidthstr);
		bottom_survey.style.width = clwidthstr;
		bottom_survey.style.display = 'inline-block'
		ext_survey.id = 'ext_survey';
		ext_survey.src = your_survey_url;
		ext_survey.style.width = '100%';
		ext_survey.style.height = '100%';
		bottom_survey.appendChild(ext_survey);
		leftcolumn = document.getElementById("img_key");
		leftcolumn.style.top = '50%';
		leftcolumn.style.width = (img_width + 20).toString() +'px';
		leftcolumn.style.transform = 'translateY(50%)';
		selectImage();
		
		window.addEventListener( 'resize', onWindowResize, false );
		
	}
	function onWindowResize(){
		clwidth = document.body.clientWidth;
		clwidth -= img_width + 20;
		clwidthstr = clwidth.toString() + 'px';
		console.log(clwidthstr);
		bottom_survey.style.width = clwidthstr;
		leftcolumn.style.top = '50%';
		leftcolumn.style.transform = 'translateY(50%)';
		
		
	}
	
	function compare(a, b){
			if (this.visits < this.visits){return -1;}
			if (this.visits > this.visits){return 1;}
			return 0;
		}
	
	function selectImage(){
		imageFilename = <?php echo json_encode($imgName); ?>;
		var imageFileDir ='images/' + imageFilename;
		var imageFileStrings = imageFilename.split(".");
		imageFileNum = imageFileStrings[0];
		setPicID();
		//plcer 
		var img_place = document.getElementById('image-wrapper');
		document.getElementById('top-reference').style.width = img_width.toString() +'px';
		img_place.style.width = img_width.toString() +'px';
		var img_tag = document.createElement('img');
		img_tag.src = imageFileDir;
		img_place.appendChild(img_tag);
	}
	function postData() {

		endTime = Date.now();
		endDate = new Date();

		var dataFilename = "output/" + surveyHITCode + ".json";
		dataFilename = dataFilename.replace(/[\r\n]/g, "");
		console.log(dataFilename);
		var postURL = "saveFile.php?filename=" + dataFilename + "&name=" + mTurkWorkerID;
		console.log(postURL);
		
		//'sessionID' : sessionID,
		var metaData = {
			"dataFilename" : dataFilename,
			"date" : endDate,
			'mTurkWorkerID' : mTurkWorkerID, 
			'mTurkAssignmentID' : mTurkAssignmentID, 
			'mTurkHitID' : mTurkHitID,
			'ProjectName' : projectTitle,
			'imageName' : imageFilename,
			'surveyHITCode':surveyHITCode
			};

		

		var dataFile = {"metaData":metaData};
		dataFileJSON = JSON.stringify(dataFile);

		var ajax = new XMLHttpRequest();

		ajax.open("POST", postURL, false);
		ajax.setRequestHeader("Content-Type", "application/upload");
		ajax.send(dataFileJSON); //send data and json object with worker/job info.

	}
	
	function setPicID() {
		var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		surveyHITCode = "";
		for (var i=0; i < 6; i++ ) { surveyHITCode += possible.charAt(Math.floor(Math.random() * possible.length)); }
		surveyHITCode = surveyHITCode + imageFileNum;
		document.getElementById('surveyCodeKey').innerHTML = surveyHITCode;
	}
	function setSessionID() {
		var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		sessionID = "";
		for (var i=0; i < 19; i++ ) { sessionID += possible.charAt(Math.floor(Math.random() * possible.length)); }
		//sessionID += confirmation_string;	
	}
	
	
	function getURLParameter( name ){
		name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
		var regexS = "[\\?&]"+name+"=([^&#]*)";
		var regex = new RegExp( regexS );
		var results = regex.exec( window.location.href );
		if( results == null )
			return "";
		else
			return results[1];
		}
	
</script>
<style>
	body{
		margin : 0px
	}

</style>
</head>
<body>
<input type = "hidden" id = "workerID" value = "" />

<div id="survey-wrap" style ="width:100%; height:100%; display:inline-block">
<div id="bottom_survey" style ="height:100%"></div>
<div id="img_key" style="top:50%; transform: translateY(50%)">
	<span align="center">
		<div id="top-reference" style = "padding:10px; display:inline-block"><p id="surveyCodeKey" ></p></div>
		<div id="image-wrapper" style = "padding:10px; display:inline-block;" ></div>
	</span>
</div>
</div>
<script type="text/javascript">
	init();
	//setSessionID();
	if (mTurkWorkerID == null || mTurkWorkerID == ""){
		mTurkWorkerID = prompt("Please enter your Mechanical Turk Worker ID. (Not your email)");
		mTurkWorkerID = mTurkWorkerID.replace(/[\r\n]/g, "");
		document.getElementById("workerID").value = mTurkWorkerID;
		$.post('session_write.php', { 'turker': mTurkWorkerID, 'assignmentID': mTurkAssignmentID, 'hitID': mTurkHitID});
		
		
	}
	
	postData();
	
</script>

</body>

</html>
