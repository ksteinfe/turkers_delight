<?php
	
	session_start();
	if (isset($_POST["turker"])) {$_SESSION["turker"] = $_POST["turker"];}
	if (isset($_POST['assignmentID'])) {$_SESSION['assignmentID'] = $_POST['assignmentID'];}
	if (isset($_POST['hitID'])) {$_SESSION['hitID'] = $_POST['hitID'];}
?>